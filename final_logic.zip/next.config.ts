/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'images.zafyfashion.com',
      },
      {
        protocol: 'https',
        hostname: '*.r2.dev',           // backup for old URLs
      },
      {
        protocol: 'https',
        hostname: 'lh3.googleusercontent.com', // Google profile pictures
      },
    ],
  },
};

module.exports = nextConfig;