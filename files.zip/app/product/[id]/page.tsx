// app/product/[id]/page.tsx
"use client";

import { useParams } from "next/navigation";
import Image from "next/image";
import { useEffect, useState } from "react";

export default function ProductDetail() {
  const params = useParams();
  const id = params.id as string;

  const [product, setProduct] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const res = await fetch(`/api/products/${id}`);
        if (!res.ok) throw new Error("Product not found");
        const data = await res.json();
        setProduct(data);
      } catch (error) {
        console.error("Failed to fetch product", error);
      } finally {
        setLoading(false);
      }
    };

    fetchProduct();
  }, [id]);

  const addToCart = () => {
    if (!product) return;

    const cart = JSON.parse(localStorage.getItem("cart") || "[]");
    const existing = cart.find((item: any) => item.id === product.id);

    if (existing) {
      existing.quantity += quantity;
    } else {
      cart.push({ ...product, quantity });
    }

    localStorage.setItem("cart", JSON.stringify(cart));
    alert(`${quantity} × ${product.title} added to cart!`);
  };

  const buyNow = () => {
    alert("Buy Now functionality will be implemented soon (Checkout flow)");
    // Future: redirect to checkout with this product
  };

  if (loading) return <div className="text-center py-20 text-xl">Loading product...</div>;
  if (!product) return <div className="text-center py-20 text-xl">Product not found</div>;

  const discount = product.discountPercentage || 0;
  const hasDiscount = discount > 0 && product.compareAtPrice && product.compareAtPrice > product.price;

  return (
    <div className="max-w-7xl mx-auto px-6 py-10">
      <div className="flex flex-col lg:flex-row gap-12">
        {/* Left - Images */}
        <div className="lg:w-1/2">
          <div className="relative aspect-square bg-gray-100 rounded-2xl overflow-hidden border">
            <Image
              src={product.images[selectedImage] || "/placeholder.jpg"}
              alt={product.title}
              fill
              className="object-cover"
            />
          </div>

          {/* Thumbnails */}
          <div className="flex gap-4 mt-6 overflow-x-auto pb-4">
            {product.images.map((img: string, index: number) => (
              <button
                key={index}
                onClick={() => setSelectedImage(index)}
                className={`relative w-20 h-20 rounded-xl overflow-hidden border-2 transition flex-shrink-0 ${
                  selectedImage === index ? "border-black" : "border-transparent"
                }`}
              >
                <Image
                  src={img}
                  alt={`Thumbnail ${index}`}
                  fill
                  className="object-cover"
                />
              </button>
            ))}
          </div>
        </div>

        {/* Right - Details */}
        <div className="lg:w-1/2">
          {/* Sale Badge */}
          {hasDiscount && (
            <span className="inline-block bg-red-500 text-white text-sm font-bold px-5 py-1 rounded-full mb-4">
              SALE
            </span>
          )}

          <h1 className="text-3xl font-medium leading-tight">{product.title}</h1>

          {/* Price */}
          <div className="flex items-baseline gap-4 mt-6">
            <span className="text-4xl font-semibold">₹{product.price}</span>
            {hasDiscount && (
              <span className="text-2xl text-gray-400 line-through">
                ₹{product.compareAtPrice}
              </span>
            )}
          </div>

          {/* Quantity Selector */}
          <div className="mt-8 flex items-center gap-6">
            <span className="text-sm font-medium">Quantity</span>
            <div className="flex items-center border border-gray-300 rounded-lg">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="w-10 h-10 flex items-center justify-center hover:bg-gray-100"
              >
                −
              </button>
              <span className="w-12 text-center font-medium">{quantity}</span>
              <button
                onClick={() => setQuantity(quantity + 1)}
                className="w-10 h-10 flex items-center justify-center hover:bg-gray-100"
              >
                +
              </button>
            </div>
          </div>

          {/* Buttons */}
          <div className="mt-8 space-y-4">
            <button
              onClick={addToCart}
              className="w-full border border-black py-4 rounded-xl font-medium hover:bg-gray-50 transition"
            >
              Add to Cart
            </button>

            <button
              onClick={buyNow}
              className="w-full bg-black text-white py-4 rounded-xl font-medium hover:bg-gray-800 transition flex items-center justify-center gap-2"
            >
              Buy it now →
            </button>
          </div>

          {/* Trust Badges */}
          <div className="mt-12 space-y-4 text-sm">
            <div className="flex items-center gap-3">
              <span>🔒</span>
              <span>100% secure and safe transaction</span>
            </div>
            <div className="flex items-center gap-3">
              <span>✅</span>
              <span>100% genuine products</span>
            </div>
            <div className="flex items-center gap-3">
              <span>🤝</span>
              <span>Authorised dealers</span>
            </div>
            <div className="flex items-center gap-3">
              <span>💡</span>
              <span>Leaders in watch retail since many years</span>
            </div>
          </div>

          {/* Description & Shipping */}
          <div className="mt-14 border-t pt-8">
            <details className="group">
              <summary className="font-medium cursor-pointer flex justify-between items-center py-4 border-b">
                Description
                <span className="text-xl group-open:rotate-45 transition">+</span>
              </summary>
              <div className="py-6 text-gray-700 leading-relaxed">
                {product.description || "No description available."}
              </div>
            </details>

            <details className="group">
              <summary className="font-medium cursor-pointer flex justify-between items-center py-4 border-b">
                Shipping Policy
                <span className="text-xl group-open:rotate-45 transition">+</span>
              </summary>
              <div className="py-6 text-gray-700">
                Free delivery all over India. Cash on Delivery available.
              </div>
            </details>
          </div>
        </div>
      </div>
    </div>
  );
}