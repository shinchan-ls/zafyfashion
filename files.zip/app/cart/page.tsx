"use client";

import { useEffect, useState } from "react";

export default function CartPage() {
  const [cart, setCart] = useState<any[]>([]);

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem("cart") || "[]");
    setCart(stored);
  }, []);

  const updateCart = (updatedCart: any[]) => {
    setCart(updatedCart);
    localStorage.setItem("cart", JSON.stringify(updatedCart));
  };

  const increaseQty = (index: number) => {
    const updated = [...cart];
    updated[index].quantity += 1;
    updateCart(updated);
  };

  const decreaseQty = (index: number) => {
    const updated = [...cart];

    if (updated[index].quantity > 1) {
      updated[index].quantity -= 1;
    } else {
      updated.splice(index, 1);
    }

    updateCart(updated);
  };

  const removeItem = (index: number) => {
    const updated = [...cart];
    updated.splice(index, 1);
    updateCart(updated);
  };

  const total = cart.reduce(
    (acc, item) => acc + item.price * item.quantity,
    0
  );

  return (
    <div className="p-5">
      <h1 className="text-2xl font-bold mb-4">Cart</h1>

      {cart.length === 0 && <p>Your cart is empty</p>}

      {cart.map((item, index) => (
        <div
          key={index}
          className="border p-3 mb-3 rounded-lg flex justify-between items-center"
        >
          <div>
            <h2 className="font-semibold">{item.name}</h2>
            <p>₹{item.price}</p>

            <div className="flex items-center gap-2 mt-2">
              <button
                onClick={() => decreaseQty(index)}
                className="px-2 bg-gray-200"
              >
                -
              </button>

              <span>{item.quantity}</span>

              <button
                onClick={() => increaseQty(index)}
                className="px-2 bg-gray-200"
              >
                +
              </button>
            </div>
          </div>

          <button
            onClick={() => removeItem(index)}
            className="text-red-500"
          >
            Remove
          </button>
        </div>
      ))}

      {cart.length > 0 && (
        <div className="mt-5">
          <h2 className="text-xl font-bold">Total: ₹{total}</h2>

          <button className="mt-3 bg-black text-white px-5 py-2 rounded-lg">
            Proceed to Checkout
          </button>
        </div>
      )}
    </div>
  );
}